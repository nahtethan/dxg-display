#!/bin/bash

# max
# ~/Desktop/mirror/mirror -w 1600 -h 1200
~/Desktop/mirror/mirror -w 1376 -h 1032
# ~/Desktop/mirror/mirror -w 1200 -h  900
# ~/Desktop/mirror/mirror -w 1024 -h  768
# ~/Desktop/mirror/mirror -w  800 -h  600

# maxcarta
# ~/Desktop/mirror/mirror -w 2200 -h 1640
# ~/Desktop/mirror/mirror -w 1648 -h 1228
# ~/Desktop/mirror/mirror -w 1376 -h 1032
# ~/Desktop/mirror/mirror -w 1100 -h  820
# ~/Desktop/mirror/mirror -w  824 -h  614
