#!/bin/bash
~/Desktop/mirror/mirror 192.168.23.3
# ~/Desktop/mirror/black 192.168.23.3
