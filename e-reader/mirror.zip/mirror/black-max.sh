#!/bin/bash

# max
# ~/Desktop/mirror/black -w 1600 -h 1200
# ~/Desktop/mirror/black -w 1376 -h 1032
# ~/Desktop/mirror/black -w 1200 -h  900
# ~/Desktop/mirror/black -w 1024 -h  768
# ~/Desktop/mirror/black -w  800 -h  600

# maxcarta
# ~/Desktop/mirror/black -w 1648 -h 1228
~/Desktop/mirror/black -w 1376 -h 1032
