#!/bin/bash

# max2支持小于2200x1650的任意分辨率组合
~/Desktop/mirror/mirror -t max2 192.168.1.22 -w 2200 -h 1650

# max
# ~/Desktop/mirror/mirror -t max 192.168.1.22
# ~/Desktop/mirror/mirror -t max 192.168.1.22 -w 1376 -h 1032
# ~/Desktop/mirror/mirror -t max 192.168.1.22 -w 1200 -h  900
# ~/Desktop/mirror/mirror -t max 192.168.1.22 -w 1024 -h  768
# ~/Desktop/mirror/mirror -t max 192.168.1.22 -w  800 -h  600

# maxcarta
# ~/Desktop/mirror/mirror -t maxcarta 192.168.1.22
# ~/Desktop/mirror/mirror -t maxcarta 192.168.1.22 -w 1648 -h 1228
# ~/Desktop/mirror/mirror -t maxcarta 192.168.1.13 -w 1376 -h 1032
# ~/Desktop/mirror/mirror -t maxcarta 192.168.1.22 -w  824 -h  614
