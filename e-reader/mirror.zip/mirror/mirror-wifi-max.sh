#!/bin/bash

# max
# ~/Desktop/mirror/mirror -t max 192.168.1.22
~/Desktop/mirror/mirror -t max 192.168.1.22 -w 1376 -h 1032
# ~/Desktop/mirror/mirror -t max 192.168.1.22 -w 1200 -h  900
# ~/Desktop/mirror/mirror -t max 192.168.1.22 -w 1024 -h  768
# ~/Desktop/mirror/mirror -t max 192.168.1.22 -w  800 -h  600

# maxcarta
# ~/Desktop/mirror/mirror -t maxcarta 192.168.1.22
# ~/Desktop/mirror/mirror -t maxcarta 192.168.1.22 -w 1648 -h 1228
# ~/Desktop/mirror/mirror -t maxcarta 192.168.1.22 -w 1376 -h 1032
# ~/Desktop/mirror/mirror -t maxcarta 192.168.1.22 -w 1100 -h  820
# ~/Desktop/mirror/mirror -t maxcarta 192.168.1.22 -w  824 -h  614
